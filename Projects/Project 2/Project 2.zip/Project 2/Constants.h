//
//  Constants.h
//  Project 2
//
//  Created by Danielle Rodriguez on 11/11/13.
//  Copyright (c) 2013 sdrodrig. All rights reserved.
//

#ifndef Project_2_Constants_h
#define Project_2_Constants_h
#define kLeftMargin 20.0
#define kTopMargin  20.0
#define kRightMargin    20.0
#define kTweenMargin    6.0
#define kTextFieldHeight 30.0



#endif
