//  ModelData.m
//  Project 2


#import "ModelData.h"

@implementation ModelData

@end
