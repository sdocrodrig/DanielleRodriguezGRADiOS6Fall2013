//  ModelData.h
//  Project 2

#import <Foundation/Foundation.h>

@interface ModelData : NSObject

@property (copy, nonatomic) NSString *personInput;
@property (copy, nonatomic) NSString *streetnameInput;
@property (copy, nonatomic) NSString *phoneNoInput;

@property (copy, nonatomic) NSString *orgTitleTrigger;

@end
