//
//  main.m
//  Project 2
//
//  Created by Danielle Rodriguez on 11/8/13.
//  Copyright (c) 2013 sdrodrig. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MADAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MADAppDelegate class]));
    }
}
